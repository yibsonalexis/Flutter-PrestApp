class Person {
    int id;
    int adminId;
    String name;
    String lname;
    String identification;
    String addres;
    String landline;
    String cellPhone;
    String email;
    String date;
    String imgs;
    int isActive;

    Person({
        this.id,
        this.adminId,
        this.name,
        this.lname,
        this.identification,
        this.addres,
        this.landline,
        this.cellPhone,
        this.email,
        this.date,
        this.imgs,
        this.isActive,
    });

    factory Person.fromJson(Map<String, dynamic> json) => new Person(
        id      : json["id"],
        adminId : json["admin_id"],
        name    : json["name"],
        lname   : json["lname"],
        identification: json["identification"],
        addres  : json["addres"],
        landline: json["landline"],
        cellPhone: json["cellPhone"],
        email: json["email"],
        date : json["date"],
        imgs : json["imgs"],
        isActive: json["isActive"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "admin_id": adminId,
        "name": name,
        "lname": lname,
        "identification": identification,
        "addres": addres,
        "landline": landline,
        "cellPhone": cellPhone,
        "email": email,
        "date": date,
        "imgs": imgs,
        "isActive": isActive,
    };
}
